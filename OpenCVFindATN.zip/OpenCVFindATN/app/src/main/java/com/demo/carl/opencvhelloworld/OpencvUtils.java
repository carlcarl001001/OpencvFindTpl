package com.demo.carl.opencvhelloworld;

import android.graphics.Bitmap;
import android.graphics.RectF;

import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

public class OpencvUtils {
    public static RectF templateMatch(Bitmap tpl, Bitmap bitmap){
        Mat src = new Mat();
        Mat tplMat = new Mat();
        Utils.bitmapToMat(bitmap,src);
        Utils.bitmapToMat(tpl,tplMat);
        int width = bitmap.getWidth() - tpl.getWidth()+1;
        int height = bitmap.getHeight() - tpl.getHeight() + 1;
        Mat result = new Mat(width,height, CvType.CV_32FC1);
        Imgproc.matchTemplate(src,tplMat,result, Imgproc.TM_CCORR_NORMED);
        Core.normalize(result,result,0,1.0, Core.NORM_MINMAX,-1);
        Core.MinMaxLocResult minMaxLocResult = Core.minMaxLoc(result);
        Point pt = minMaxLocResult.maxLoc;
        Core.rectangle(src,pt,new Point(pt.x+ tpl.getWidth(),pt.y+tpl.getHeight()),
                new Scalar(255,0,0,0),5,8,0);
        Utils.matToBitmap(src,bitmap);
        src.release();
        result.release();
        tplMat.release();
        return new RectF((float)pt.x,(float) pt.y,(float)(pt.x+ tpl.getWidth()),(float)(pt.y+tpl.getHeight()));
    }
}
















